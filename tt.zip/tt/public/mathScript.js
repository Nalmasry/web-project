function getValue(){
    if(document.getElementById('second').checked) {
            document.getElementById('output').innerHTML = "<p>Amazingg!!</p>"
    }else if(document.getElementById('first').checked) {
            document.getElementById('output').innerHTML = "<p>wrong, please try again</p>"
    }else if(document.getElementById('third').checked) {
            document.getElementById('output').innerHTML = "<p>wrong, please try again</p>"
    }

}

function getValue2(){
    if(document.getElementById('third').checked) {
            document.getElementById('output').innerHTML = "<p>Amazingg!!</p>"
    }else if(document.getElementById('first').checked) {
            document.getElementById('output').innerHTML = "<p>wrong, please try again</p>"
    }else if(document.getElementById('second').checked) {
            document.getElementById('output').innerHTML = "<p>wrong, please try again</p>"
    }

}

function getValue3(){
    if(document.getElementById('first').checked) {
            document.getElementById('output').innerHTML = "<p>Amazingg!!</p>"
    }else if(document.getElementById('second').checked) {
            document.getElementById('output').innerHTML = "<p>wrong, please try again</p>"
    }else if(document.getElementById('third').checked) {
            document.getElementById('output').innerHTML = "<p>wrong, please try again</p>"
    }

}
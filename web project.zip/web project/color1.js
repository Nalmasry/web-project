image1 = new Image();
image1.src = "red.png";
image2 = new Image();
image2.src = "red1.png";

image3 = new Image();
image3.src = "yellow.webp";
image4 = new Image();
image4.src = "yellow1.png";

image5 = new Image();
image5.src = "green.webp";
image6 = new Image();
image6.src = "green1.png";



function mouseOver( e )
{
    if(e.target.getAttribute("id") == "red")
    {
        e.target.setAttribute("src" , image2.getAttribute("src"));
    }

    if(e.target.getAttribute("id") == "yellow")
    {
        e.target.setAttribute("src" , image4.getAttribute("src"));
    }
    
    if(e.target.getAttribute("id") == "green")
    {
        e.target.setAttribute("src" , image6.getAttribute("src"));
    }
}

function mouseOut( e )
{
    if(e.target.getAttribute("id") == "red")
    {
        e.target.setAttribute("src" , image1.getAttribute("src"));
    }

    if(e.target.getAttribute("id") == "yellow")
    {
        e.target.setAttribute("src" , image3.getAttribute("src"));
    }

    if(e.target.getAttribute("id") == "green")
    {
        e.target.setAttribute("src" , image5.getAttribute("src"));
    }
   
}

document.addEventListener("mouseover", mouseOver, false)
document.addEventListener("mouseout" , mouseOut , false)